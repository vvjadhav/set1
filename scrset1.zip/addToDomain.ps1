﻿param($dnsZone,$usr,$pw)
$passwd1=$pw.Split('~')
write-host $dnsZone,$usr #,$passwd1
foreach($i in $passwd1)
{
$s= $s + ([char][int]$i)
}

#write-host "Password1 : " $s

# Define Credentials:
[string]$userName = $dnsZone + '\' + $usr

# Crete credential Object
[SecureString]$userPassword = $s | ConvertTo-SecureString -AsPlainText -Force 
[PSCredential]$cred = New-Object System.Management.Automation.PSCredential -ArgumentList $userName,$userPassword
Add-Computer -DomainName $dnsZone -Credential $cred -verbose # -restart -force Note that the computer needs to be restarted automatically

